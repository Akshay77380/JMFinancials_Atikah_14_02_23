// ignore_for_file: non_constant_identifier_names,library_prefixes,unused_import,camel_case_types
mixin VolumeEntity {
   double open;
   double close;
   double vol;
  double MA5Volume;
  double MA10Volume;
}
