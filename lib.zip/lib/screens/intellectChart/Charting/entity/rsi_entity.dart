mixin RSIEntity {
  double oB = 70.0;
  double oS = 30.0;
  List<double> rsi;
}
