mixin CCIEntity {
  List<double> cci;
}
