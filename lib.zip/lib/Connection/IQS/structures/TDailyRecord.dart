class TDailyRecord {
  int trades = 0;
  double value = 0;
  double open = 0;
  double high = 0;
  int date = 0;
  double low = 0;
  double close = 0;
  int qty = 0;
}
