abstract class NetworkConnection {
  void notifyInternet();
}
