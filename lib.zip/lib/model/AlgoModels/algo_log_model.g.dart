// // GENERATED CODE - DO NOT MODIFY BY HAND
//
// part of 'algo_log_model.dart';
//
// // **************************************************************************
// // StoreGenerator
// // **************************************************************************
//
// // ignore_for_file: non_constant_identifier_names, unnecessary_brace_in_string_interps, unnecessary_lambdas, prefer_expression_function_bodies, lines_longer_than_80_chars, avoid_as, avoid_annotating_with_dynamic, no_leading_underscores_for_local_identifiers
//
// mixin _$AlgoLogModel on _AlgoLogModelBase, Store {
//   final _$algoLogAtom =
//   Atom(name: '_AlgoLogModelBase.algoLog', );
//
//   @override
//   AlgoLog get algoLog {
//     _$algoLogAtom.reportRead();
//     return super.algoLog;
//   }
//
//   @override
//   set algoLog(AlgoLog value) {
//     _$algoLogAtom.reportWrite(value, super.algoLog, () {
//       super.algoLog = value;
//     });
//   }
//
//   final _$algoLogListsAtom =
//   Atom(name: '_AlgoLogModelBase.algoLogLists', );
//
//   @override
//   ObservableList<AlgoLog> get algoLogLists {
//     _$algoLogListsAtom.reportRead();
//     return super.algoLogLists;
//   }
//
//   @override
//   set algoLogLists(ObservableList<AlgoLog> value) {
//     _$algoLogListsAtom.reportWrite(value, super.algoLogLists, () {
//       super.algoLogLists = value;
//     });
//   }
//
//   final _$_AlgoLogModelBaseActionController =
//   ActionController(name: '_AlgoLogModelBase',);
//
//   @override
//   void updateGetAlgoLogOrders(bool value) {
//     final _$actionInfo = _$_AlgoLogModelBaseActionController.startAction(
//         name: '_AlgoLogModelBase.updateGetAlgoLogOrders');
//     try {
//       return super.updateGetAlgoLogOrders(value);
//     } finally {
//       _$_AlgoLogModelBaseActionController.endAction(_$actionInfo);
//     }
//   }
//
//   @override
//   String toString() {
//     return '''
// algoLog: ${algoLog},
// algoLogLists: ${algoLogLists}
//     ''';
//   }
// }
